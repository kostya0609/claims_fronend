<template>
  <div class="body-wrapper">
    <el-row>
    <el-col :span="6">
      <label class="add_claims_label">Дата начала периода</label>
      <el-date-picker
          v-model="dateStart"
          :class="errors.dateStart ? 'invalid' : ''"
          style="width: 100%"
          type="date"
          format="DD.MM.YYYY"
          valueFormat="DD.MM.YYYY"
          placeholder="Выберите дату"
      >
      </el-date-picker>
      <small v-if="errors.dateStart">{{errors.dateStart}}</small>
    </el-col>
    <el-col :span="1">
    </el-col>
    <el-col :span="6">
      <label class="add_claims_label">Дата окончания периода </label>
      <el-date-picker
          v-model="dateFinal"
          :class="errors.dateFinal ? 'invalid' : ''"
          style="width: 100%"
          type="date"
          format="DD.MM.YYYY"
          valueFormat="DD.MM.YYYY"
          placeholder="Выберите дату"
      >
      </el-date-picker>
      <small v-if="errors.dateFinal">{{errors.dateFinal}}</small>
    </el-col>
    <el-col :span="1">
      </el-col>
    <el-col :span="6">
      <label class="add_claims_label"><br/></label>
      <el-button
          icon="el-icon-download"
          class="claim-save-element-button"
          @click="submit"
      >
        Сформировать отчет
      </el-button>
    </el-col>
  </el-row>
  </div>
</template>

<script>
import {ref, reactive, watchEffect, inject} from 'vue'
export default {
  name: "Report",
  setup(){
    const loadJson  = inject('loadJson');
    const notify    = inject('notify');

    const dateStart = ref(null);
    const dateFinal = ref(null);

    const errors = reactive({
      dateStart : null,
      dateFinal : null,
    });

    async function submit(){
      if(dateStart.value && dateFinal.value){

        try {
          let result = await loadJson('/claims/report', {date_start : dateStart.value, date_final : dateFinal.value}, '', true); //параметры - url, объкт с данными(id файла), type (если указать 'file' то это для отправки файла и отсылаемые данные уйдут не json-ом а как форма), downLoadRequest - если true то результат не будет преобразован через json )
          let blob      = await result.blob();
          let url       = URL.createObjectURL(blob);
          let link      = document.createElement('a');
          link.href     = url;
          link.download = 'отчет за период с '+dateStart.value + ' по ' + dateFinal.value + '.xlsx';
          link.click();
          URL.revokeObjectURL(link.href);
        }catch(e){
          notify('Ошибка загрузки файла', e.message, e.status)
        }

      } else {
        dateStart.value ? '' : errors.dateStart = 'Необходимо указать дату начала периода';
        dateFinal.value ? '' : errors.dateFinal = 'Необходимо указать дату окончания периода';
      }
    }

    watchEffect(() => {
      dateStart.value ? errors.dateStart = null : '';
      dateFinal.value ? errors.dateFinal = null : '';
    })

    return{dateStart, dateFinal, errors, submit}
  },
}
</script>

<style scoped>

</style>